		
		****** Only Compatible with Windows 10 ******
Made by: earningpton@github
################################################################################
   #####               		-PLEASE BOT 1.00"-			#####
################################################################################
#####		             .  _    .-.. 
##### 		             ( `' ;  .( ; ; 
##### 		           .-`() .;(_.{}:  
##### 		            `..'`,' / ' ;.) 
#####  		             `-'\ /  `-' 
##### 		          _,--*dSS|--ISSSSS%cccc, 
##### 		      <SSSb |SSSl  jSSSSSSSSSSSSSSbp 
##### 		       \SSSb|SSSS  dSSSSSSSSSSSSSSP 
##### 		        \SSSSSSSS; SSSSSSSSSSSSSSP 
##### 		         \SSSSSSS| SSSSSSSSSSSSSP 
##### 		          )SSSSSS_SSSSSSSSSSSSSS( 
#####  		         Y--               ---P")
#####  		          \ ____.G._          _/         
##### 		  _.,cccccd%SSSSSSSSSSSSSSSSS%dcccc,._ 
#####		 (SSSSSSSSSSSSSSSSSSSSSSSSS$SSSSSSSSSSSS) 
##### 		  `------Y-'                  `-SSSSSSP-)-) 
Art Credit:http://ascii.co.uk and www.asciiart.eu
################################################################################
   #####               		    -Manual-			        #####
################################################################################

Readme:
For the first time user you should say "please override username" and then say your name to personalize the bot

Don't turn your sound off or unplug the headphone or the program will shut down
Please forward any bug in the program to <a> yomjinda@princeton.edu </a>

Functionality Summary: Please Bot is a windows 10-based chatbot and personal assistant in one package, created in Python 3.6 but require no Python to run whatsoever. It can access internet and desired website quickly through voice-based command, tell a joke, learn a one liner, and even swear back at you for using bad words. 

################################################################################
   #####               		  -How to Use-			        #####
################################################################################

Opening: Double click on the exe file to open the program, make sure to extract the zip file first and that the json file is in the same directory as exe file

Using: The Please bot only recognize commands that start with either "please" or "would you kindly" since these are quite rare words today, even more so that "Siri" but probably less rare than "Cortana". It then recognizes whatever come after "please" or "would you kindly" as a command.

There are three types of command: all has to be initiated with "please" or "would you kindly"

**ORDER COMMANDS***: issues order
	-search: search the key words on Google ex: "please search where does Koala lives"
	-open/browse: open the best match website ex: "please open Nicki Minaj Anaconda Youtube" will open Anaconda music video on YouTube
	-tell a joke: tell random joke ex:"please tell a joke"
	-where is: open the location desired on Google map ex. "please where is Princeton University" 
	-what time is it: speaks the current time
	-what day is it: speaks current date
	-how are you/hi/hey/hello: says hi to the bot, it is not a human though but it can learn something

**LEARNING Q&A COMMANDS***: learn a one liner answer, good for keeping notes/ remember password for your favorite website/ program
	-tell me: give answer to question. if no answer, note in new answer for the question asked
	ex. "please tell me where I hid my key" no answer first time so the user say "in the desk drawer" and confirm by saying "yes" after hearing "are you sure"
	next time we asked "please tell me where I hid my key", the program will say, in the desk drawer
	-override: override the answer and also the username. For first time user you should say "please override username" and then say your name to personalize the bot. It can also be used to override the tell me answer 
	ex. "please override where I hid my key" and saide "in my car"

Note: alternatively, you can change json file manually but beware of the format

***CLOSING COMMAND***: close the application
	-that's good for today: close the application
	-ctrl+c exit program manually, no need to say the word